<?php namespace App\Models;

use CodeIgniter\Model;

class Dashboard_Model extends Model
{

}
